
Basic pro layouts

b) gradient overlays on pictures (5m) [SUP ONE](SUP ONE)
c) text on pictures (5m) [SUP TWO](SUP TWO)
d) "background-image" intricacies [SUP THREE](SUP THREE)
e) position: absolute intricacies [SUP FOUR](SUP FOUR)
f) centering anything [SUP FIVE](SUP FIVE)
g) box-shadow and border


EXERCISE: [SUP SIX](SUP SIX)


javascript and CSS

- Creating elements [SUP SEVEN](SUP SEVEN)
- getting DOM elements as JS obects (the https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement interface) [SUP 8](SUP EIGHT)
- Adding/removing classes to elements in JavaScript [SUP NINE](SUP NINE)
- Adding/removing inline styles to elements JavaScript  [SUP 10](SUP 10)
- HTML game hacks
- JavaScript v.s. React


Exercise: [SUP 11](SUP 11)
